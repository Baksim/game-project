import os
from flask import Flask, jsonify, render_template, redirect, url_for, flash
from flask_login import LoginManager, login_user, logout_user
from flask_sqlalchemy import SQLAlchemy
from flask_migrate import Migrate
from flask import request
from elopy import elopy
from forms import RegistrationForm, LoginForm
from uuid import uuid4

app = Flask(__name__)
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
if not os.environ.get('IS_HEROKU') == 'True':
    app.config.from_object('config.DevelopmentConfig')
else:
    app.config.from_object('config.ProductionConfig')

db = SQLAlchemy(app)
migrate = Migrate(app, db)
login_manager = LoginManager()
login_manager.init_app(app)

from models import User

@login_manager.user_loader
def load_user(user_id):
    return User.query.filter_by(id=user_id).first()

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/register', methods=['POST', 'GET'])
def register():
    form = RegistrationForm()
    if form.validate_on_submit():
        user = User(username=form.username.data, email=form.email.data)
        user.set_password(form.confirm_password.data)
        db.session.add(user)
        db.session.commit()
        return redirect(url_for('login'))
    return render_template('registration.html', form=form)

@app.route('/login', methods=['GET', 'POST'])
def login():
    form = LoginForm()
    if form.validate_on_submit():
        user = User.query.filter_by(email=form.email.data).first()
        if user is not None and user.check_password(form.password.data):
            login_user(user)
            return redirect(url_for('index'))
        flash('Invalid email address or password.')
    return render_template('login.html', form=form)

@app.route("/logout")
def logout():
    logout_user()
    return redirect(url_for('index'))

@app.route('/logout_api', methods=['POST'])
def api_logout():
    user = User.query.filter_by(session_id=request.form['session_id']).first()
    setattr(user, 'session_id', None)
    db.session.commit()
    return 'Logged out', 200

@app.route('/register_api', methods=['POST'])
def api_register():
    user = User(username=request.form['username'], email=request.form['email'])
    user.set_password(request.form['password'])
    db.session.add(user)
    db.session.commit()
    return 'Registered', 200

@app.route('/login_api', methods=['GET'])
def api_login():
    user = User.query.filter_by(email=request.form['email']).first()
    if user is not None:
        if user.check_password(request.form['password']):
            session_id = uuid4()
            setattr(user, 'session_id', session_id)
            db.session.commit()
            return jsonify({'session_id': session_id})
        else:
            return "Incorrect password", 400
    else:
        return "User not found", 400

def get_info(session_id):
    user = User.query.filter_by(session_id=session_id).first()
    if user is None:
        return None
    else:
        info = {
            "username": user.username,
            "email": user.email,
            "score": user.score,
        }
        return info

@app.route('/get_user_info', methods=['GET'])
def get_user_info():
    session_id = request.form['session_id']
    info = get_info(session_id)
    if info is None:
        return "User not found", 404
    else:
        return jsonify(info)

@app.route('/match_score', methods=['GET'])
def match_score():
    data = request.form
    user1 = get_info(data["player1"])
    user2 = get_info(data["player2"])

    i = elopy.Implementation()
    i.addPlayer(data["player1"], rating=user1["score"])
    i.addPlayer(data["player2"], rating=user2["score"])
    if data["type"] == "win":
        i.recordMatch(data["player1"], data["player2"], winner=data["winner"])
    elif data["type"] == "draw":
        i.recordMatch(data["player1"], data["player2"], draw=True)
    ratings = i.getRatingList()
    # [('Hank', 1030.2345400165577), ('Bill', 869.7654599834424)]
    result = {
        ratings[0][0]: round(ratings[0][1]),
        ratings[1][0]: round(ratings[1][1])
    }
    usr1 = User.query.filter_by(session_id=data["player1"]).first()
    usr2 = User.query.filter_by(session_id=data["player2"]).first()
    setattr(usr1, 'score', result[data["player1"]])
    setattr(usr2, 'score', result[data["player2"]])
    db.session.commit()
    i.removePlayer(data["player1"])
    i.removePlayer(data["player2"])
    return jsonify(result)

if __name__ == '__main__':
    app.run()

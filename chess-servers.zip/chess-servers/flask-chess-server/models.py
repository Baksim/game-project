from app import db
from flask_login import UserMixin
from datetime import datetime
from werkzeug.security import generate_password_hash, check_password_hash


class User(UserMixin, db.Model):
    __tablename__ = 'users'

    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(20), index=True, unique=True)
    password = db.Column(db.String(128))
    email = db.Column(db.String(56), unique=True, index=True)
    avatar = db.Column(db.String(64), nullable=True)
    created_date = db.Column(db.DateTime(), default=datetime.utcnow)
    session_id = db.Column(db.String(128), index=True)
    score = db.Column(db.SmallInteger, nullable=True)

    def __init__(self, username, email, avatar=None, created_date=datetime.utcnow()):
        self.username = username
        self.email = email
        self.avatar = avatar
        self.created_date = created_date
        self.session_id = None
        self.score = 1000

    def set_password(self, password):
        self.password = generate_password_hash(password)

    def set_session_id(self, session_id):
        self.session_id = session_id

    def check_password(self, password):
        return check_password_hash(self.password, password)


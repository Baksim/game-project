import os

class Config:
    SECRET_KEY = os.environ['SECRET_KEY']
    FLASK_SECRET = SECRET_KEY
    SQLALCHEMY_DATABASE_URI = os.environ['SQLALCHEMY_DATABASE_URI']

class ProductionConfig(Config):
    DEVELOPMENT = False
    DEBUG = False

class DevelopmentConfig(Config):
    DEVELOPMENT = True
    DEBUG = False

class TestConfig(Config):
    DEVELOPMENT = True
    DEBUG = True

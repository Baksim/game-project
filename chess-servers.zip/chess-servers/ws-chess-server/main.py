import os
import signal
import asyncio
import websockets
import secrets
import json
import chess
import requests

JOIN = {}
MATCHMAKING = {}

async def error(websocket, message):
    event = {
        "type": "error",
        "message": message,
    }
    await websocket.send(json.dumps(event))

async def replay(websocket, game):
    for move in game.move_stack.copy():
        event = {
            "type": "play",
            "code": move
        }
        await websocket.send(json.dumps(event))

async def play(websocket, game, connected, sessions):
    while True:
        async for message in websocket:
            event = json.loads(message)
            print(message)
            if event["type"] == "defeat":  # for conceded defeat
                event = {
                    "type": "win",
                    "color": event["winner"]
                }
            assert event["type"] == "play"
            code = event["code"]
            print("Received a move")
            try:
                move = chess.Move.from_uci(code)
                game.push(move)
                print("Played a move on server")
            except RuntimeError as exc:
                await error(websocket, str(exc))
                continue
            event = {
                "type": "play",
                "color": game.turn,
                "code": code,
            }
            websockets.broadcast(connected, json.dumps(event))
            print("Sent a move to the UI")

            if game.outcome() is not None:
                if game.outcome().winner is not None:
                    winner = game.outcome().winner
                    if winner == chess.WHITE:
                        winner = sessions[0]
                    else:
                        winner = sessions[1]
                    req = {
                        "type": "win",
                        "winner": winner,
                        "player1": sessions[0],
                        "player2": sessions[1]
                    }
                    scores = requests.get("https://flask-chess-server.herokuapp.com/match_score", data=req).json()
                    websockets.broadcast(connected, json.dumps(scores))
                    event = {
                        "type": "win",
                        "color": winner,
                    }
                    websockets.broadcast(connected, json.dumps(event))
                    return
                else:
                    req = {
                        "type": "draw",
                        "player1": sessions[0],
                        "player2": sessions[1]
                    }
                    scores = requests.get("https://flask-chess-server.herokuapp.com/match_score", data=req).json()
                    websockets.broadcast(connected, json.dumps(scores))
                    event = {
                        "type": "draw",
                    }
                    websockets.broadcast(connected, json.dumps(event))
                    return

async def start(websocket, session_id):
    game = chess.Board()
    connected = {websocket}
    sessions = [session_id]

    join_key = secrets.token_urlsafe(12)
    JOIN[join_key] = game, connected, sessions
    try:
        event = {
            "type": "init",
            "join": join_key,
        }
        await websocket.send(json.dumps(event))
        await play(websocket, game, connected, sessions)

    finally:
        del JOIN[join_key]
        print("This is the end for start")

async def join(websocket, join_key, session_id):
    try:
        game, connected, sessions = JOIN[join_key]
        # await websocket.send(json.dumps({"status": "OK"}))
    except KeyError:
        # await websocket.send(json.dumps({"status": "ERROR"}))
        await error(websocket, "Game not found.")
        return

    connected.add(websocket)
    sessions.append(session_id)
    try:
        # await replay(websocket, game)
        event = {
            "type": "announcement",
            "player1": sessions[0],
            "player2": sessions[1]
        }
        websockets.broadcast(connected, json.dumps(event))
        await play(websocket, game, connected, sessions)
    finally:
        del JOIN[join_key]
        print("This is the end for join")

async def match(websocket, session_id):
    if len(MATCHMAKING.keys()) == 0:
        game = chess.Board()
        connected = {websocket}
        sessions = [session_id]
        match_key = secrets.token_urlsafe(12)
        MATCHMAKING[match_key] = game, connected, sessions
        event = {
            "type": "assign_color",
            "color": chess.WHITE,
        }
        await websocket.send(json.dumps(event))
        try:
            await play(websocket, game, connected, sessions)
        finally:
            del MATCHMAKING[match_key]
            del JOIN[match_key]
    else:
        for i in MATCHMAKING:  # finding first available game in matchmaking
            MATCHMAKING[i][1].add(websocket)
            MATCHMAKING[i][2].append(session_id)
            game, connected, sessions = MATCHMAKING[i]
            JOIN[i] = MATCHMAKING[i]
            del MATCHMAKING[i]
            event = {
                "type": "assign_color",
                "color": chess.BLACK,
            }
            await websocket.send(json.dumps(event))
            try:
                event = {
                    "type": "announcement",
                    "player1": sessions[0],
                    "player2": sessions[1]
                }
                websockets.broadcast(connected, json.dumps(event))
                await play(websocket, game, connected, sessions)
            finally:
                del MATCHMAKING[i]
                del JOIN[i]
            break

async def handler(websocket):
    message = await websocket.recv()
    event = json.loads(message)
    print(MATCHMAKING) # for debugging
    assert event["type"] == "init"

    if "join" in event:
        await join(websocket, event["join"], event["session_id"])
    elif "match" in event:
        print("hello")
        await match(websocket, event["session_id"])
    else:
        await start(websocket, event["session_id"])

async def main():
    loop = asyncio.get_running_loop()
    stop = loop.create_future()
    loop.add_signal_handler(signal.SIGTERM, stop.set_result, None)

    port = int(os.environ.get("PORT", "8001"))
    async with websockets.serve(handler, "", port):
        await stop

# async def main():
#     async with websockets.serve(handler, "", 8001):
#         await asyncio.Future()  # run forever

if __name__ == "__main__":
    asyncio.run(main())
